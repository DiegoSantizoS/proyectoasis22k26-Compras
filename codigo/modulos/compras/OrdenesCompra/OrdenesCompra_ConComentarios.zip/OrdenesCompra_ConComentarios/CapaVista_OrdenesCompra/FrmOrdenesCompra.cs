﻿using CapaVista_OrdenesCompra.Presentacion;
using CapaVista_Componentes.Componentes;
using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaControlador_OrdenesCompra;
using CapaControlador_OrdenesCompra.Entidades;

/*
 * ==================================================================
 * Área : Compras
 * Autor : Diego Fernando Santizo Samayoa
 * Carné : 0901-22-15950
 * Fecha : 24/10/2026
 * ==================================================================
 * Propósito :
 *  Coordina la visualización de una orden de compra seleccionada.
 * ===================================================================
*/

/*
 * EXPLICACION TEMPORAL DE LA CLASE
 * Coordina la visualización de una orden nueva o existente, mostrando código, fechas, proveedor, importes,
 * moneda y plazo. Carga los detalles sin bloquear la interfaz y delega columnas y alturas a las clases de
 * presentación. La anulación pide confirmación y usa el PK mediante el controlador. La captura de productos
 * y el guardado de órdenes nuevas siguen deshabilitados; al cerrar libera la tabla y las suscripciones de
 * diseño.
 */

namespace CapaVista_OrdenesCompra
{
    public partial class FrmOrdenesCompra : System.Windows.Forms.Form
    {
        private readonly ClsDisenoDetallesOrdenCompra _DisenoDetalles;
        private readonly ClsOrdenesCompra _Controlador;
        private ClsOrdenCompra _Compra;
        private bool _Anulando;
        public bool OrdenGuardada { get; private set; }

        /// <summary>
        /// Construye una pantalla de orden nueva con el controlador real; la captura de productos y el guardado
        /// siguen deshabilitados.
        /// </summary>
        public FrmOrdenesCompra() : this(null, new ClsOrdenesCompra()) { }

        /// <summary>
        /// Recibe la orden opcional y el controlador, inicializa controles, configura el DGV y conecta los eventos
        /// de fechas, proveedor y anulación.
        /// </summary>
        public FrmOrdenesCompra(ClsOrdenCompra Compra, ClsOrdenesCompra Controlador)
        {
            _Controlador = Controlador ?? throw new ArgumentNullException(nameof(Controlador));
            _Compra = Compra;
            InitializeComponent();
            ClsPresentacionCompras.ComprasMetFijarTamanoFormulario(this);
            ComprasCboNombreProveedor.SelectedIndexChanged += ComprasProcActualizarProveedor;
            ComprasDtpFechaEmision.ValueChanged += ComprasProcActualizarVencimiento;
            ClsTablasOrdenesCompra.ComprasProcConfigurarDetalles(ComprasDgvProductos);
            _DisenoDetalles = new ClsDisenoDetallesOrdenCompra(this, ComprasDgvProductos,
                ComprasPnlContenido, ComprasTlpPrincipal, ComprasTlpDetalles, ComprasGbxDetalles);
            ComprasTlpMantenimientoProductos.Enabled = false;
            ComprasBtnGuardar.Enabled = false;
            ComprasBtnGuardar.AccessibleDescription = "Se requieren productos para guardar la orden.";
            ComprasBtnDescartar.AccessibleName = Compra == null ? "Descartar" : "Anular orden";
            ComprasBtnDescartar.Enabled = _Compra == null || (_Compra.Estado != "Anulada" && _Compra.Estado != "Recibida");
            ComprasBtnDescartar.Click += ComprasProcAnular;
            ComprasBtnRegresar.Click += (Remitente, Evento) => Close();
            FormClosing += (Remitente, Evento) => { if (_Anulando) Evento.Cancel = true; };
            ComprasProcMostrarEncabezado();
        }

        /// <summary>
        /// Muestra código, proveedor, fechas, importes, plazo y moneda. Distingue una orden nueva de una existente y
        /// mantiene de solo lectura los datos no editables.
        /// </summary>
        private void ComprasProcMostrarEncabezado()
        {
            bool Nueva = _Compra == null;
            ComprasLblCodigoOrden.MostrarAsterisco = Nueva;
            ComprasLblFechaDeEmision.MostrarAsterisco = Nueva;
            ComprasLblFechaDeVencimiento.MostrarAsterisco = Nueva;
            ComprasTxtCodigoOrden.Enabled = Nueva;
            ComprasTxtCodigoOrden.MaxLength = 30;
            ComprasDtpFechaEmision.Enabled = Nueva;
            ComprasDtpFechaVencimiento.Enabled = Nueva;
            ComprasCboNombreProveedor.Enabled = Nueva;
            ComprasTxtComentario.Enabled = false;
            ComprasTxtComentario.Text = Nueva ? string.Empty : _Compra.Comentario;
            ComprasTxtEstadoProveedor.Text = string.Empty;
            ComprasTxtEstadoProveedor.Enabled = false;
            ComprasTxtDireccionProveedor.Enabled = false;
            ComprasTxtCodigoOrden.Text = Nueva ? string.Empty : _Compra.CodigoOrdenCompra;
            ComprasDtpFechaEmision.Value = Nueva ? DateTime.Today : _Compra.FechaEmision;
            ComprasDtpFechaVencimiento.Value = Nueva ? ComprasDtpFechaEmision.Value.Date : _Compra.FechaVencimiento;
            ComprasTxtPlazoValor.Text = Nueva ? string.Empty : _Compra.NombrePlazo;
            ComprasLblEstadoValor.Texto = Nueva ? "Nueva" : _Compra.Estado;
            ComprasTxtMoneda.Text = Nueva ? string.Empty : _Compra.IdMoneda.ToString();
            ComprasTxtTipoCambio.Text = Nueva ? string.Empty : _Compra.TipoCambio.ToString("N6");
            ComprasTxtDiasPlazo.Text = Nueva ? string.Empty : _Compra.DiasPlazo.ToString();
            ComprasTxtSubtotal.Text = (Nueva ? 0M : _Compra.Subtotal).ToString("N4");
            ComprasTxtDescuentoTotal.Text = (Nueva ? 0M : _Compra.Descuento).ToString("N4");
            ComprasTxtTotalDeLaOrden.Text = (Nueva ? 0M : _Compra.MontoTotal).ToString("N4");
            foreach (var Campo in new[] { ComprasTxtMoneda, ComprasTxtTipoCambio, ComprasTxtDiasPlazo,
                ComprasTxtSubtotal, ComprasTxtDescuentoTotal, ComprasTxtPlazoValor })
                Campo.Enabled = false;
            ComprasTxtTotalDeLaOrden.Enabled = false;
            if (!Nueva)
            {
                ComprasCboNombreProveedor.TipoDatos = EnmTipoDatosCompras.Ninguno;
                ComprasCboNombreProveedor.DataSource = null;
                ComprasCboNombreProveedor.Items.Clear();
                ComprasCboNombreProveedor.Items.Add(_Compra.NombreProveedor);
                ComprasCboNombreProveedor.SelectedIndex = 0;
                ComprasTxtNitProveedor.Text = _Compra.NitProveedor;
                ComprasTxtTelefonoProveedor.Text = _Compra.TelefonoProveedor;
                ComprasTxtCorreoProveedor.Text = _Compra.CorreoProveedor;
                ComprasTxtDireccionProveedor.Text = _Compra.DireccionProveedor;
                ComprasTxtEstadoProveedor.Text = _Compra.ProveedorActivo ? "Activo" : "Inactivo";
            }
        }

        /// <summary>
        /// En una orden nueva copia la fecha de emisión al vencimiento; no guarda el cambio en la base.
        /// </summary>
        private void ComprasProcActualizarVencimiento(object Remitente, EventArgs Evento)
        {
            if (_Compra != null) return;
            ComprasDtpFechaVencimiento.Value = ComprasDtpFechaEmision.Value.Date;
        }

        /// <summary>
        /// Limpia la selección de proveedor si la orden es nueva; para una existente actualiza el encabezado y carga
        /// sus productos de forma asíncrona.
        /// </summary>
        protected override async void OnShown(EventArgs Evento)
        {
            base.OnShown(Evento);
            if (_Compra == null)
            {
                ComprasCboNombreProveedor.SelectedIndex = -1;
                ComprasProcActualizarProveedor(this, EventArgs.Empty);
            }
            else
            {
                ComprasProcMostrarEncabezado();
                await ComprasProcCargarDetallesAsync();
            }
        }

        /// <summary>
        /// Consulta productos fuera del hilo de interfaz y los enlaza al DGV; libera resultados tardíos y presenta
        /// los errores de carga.
        /// </summary>
        private async Task ComprasProcCargarDetallesAsync()
        {
            try
            {
                int Id = _Compra.IdOrdenCompra;
                var Detalles = await Task.Run(() => _Controlador.ComprasFuncListarDetalles(Id));
                if (IsDisposed || Disposing)
                {
                    Detalles.Dispose();
                    return;
                }
                ComprasDgvProductos.DataSource = Detalles;
                ComprasDgvProductos.ClearSelection();
            }
            catch (Exception Ex)
            {
                if (!IsDisposed && !Disposing)
                    MessageBox.Show(this, "No se pudieron cargar los detalles. " + Ex.Message,
                        "Órdenes de compra", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Desconecta el ajuste de diseño, desenlaza y libera la tabla de productos y notifica el cierre a la clase
        /// base.
        /// </summary>
        protected override void OnFormClosed(FormClosedEventArgs Evento)
        {
            _DisenoDetalles.Dispose();
            var Detalles = ComprasDgvProductos.DataSource as System.Data.DataTable;
            ComprasDgvProductos.DataSource = null;
            Detalles?.Dispose();
            base.OnFormClosed(Evento);
        }

        /// <summary>
        /// Solicita confirmación y anula mediante el PK en segundo plano, bloqueando botones y actualizando el
        /// encabezado. Si la orden no está guardada, solo cierra la pantalla.
        /// </summary>
        private async void ComprasProcAnular(object Remitente, EventArgs Evento)
        {
            if (_Anulando) return;
            if (_Compra == null) { Close(); return; }
            if (MessageBox.Show(this, "¿Anular la orden " + _Compra.CodigoOrdenCompra + "?",
                "Anular orden", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
            _Anulando = true;
            ComprasBtnDescartar.Enabled = false;
            ComprasBtnRegresar.Enabled = false;
            UseWaitCursor = true;
            try
            {
                int Id = _Compra.IdOrdenCompra;
                _Compra = await Task.Run(() => _Controlador.ComprasFuncAnular(Id));
                OrdenGuardada = true;
                ComprasProcMostrarEncabezado();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(this, "No se pudo anular la orden. " + Ex.Message,
                    "Órdenes de compra", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                _Anulando = false;
                ComprasBtnDescartar.Enabled = _Compra == null || (_Compra.Estado != "Anulada" && _Compra.Estado != "Recibida");
                ComprasBtnRegresar.Enabled = true;
                UseWaitCursor = false;
            }
        }

        /// <summary>
        /// Limpia los campos y muestra el proveedor seleccionado en una orden nueva; presenta el error del
        /// componente si falla su lectura.
        /// </summary>
        private void ComprasProcActualizarProveedor(object Remitente, EventArgs Evento)
        {
            if (_Compra != null) return;
            ComprasTxtTelefonoProveedor.Text = string.Empty;
            ComprasTxtCorreoProveedor.Text = string.Empty;
            ComprasTxtNitProveedor.Text = string.Empty;
            ComprasTxtDireccionProveedor.Text = string.Empty;
            ComprasTxtEstadoProveedor.Text = string.Empty;
            try
            {
                var Proveedor = ComprasCboNombreProveedor.ComprasFuncObtenerProveedorSeleccionado();
                if (Proveedor == null) return;
                ComprasTxtTelefonoProveedor.Text = Proveedor.TelefonoProveedor;
                ComprasTxtCorreoProveedor.Text = Proveedor.CorreoProveedor;
                ComprasTxtNitProveedor.Text = Proveedor.NitProveedor;
                ComprasTxtDireccionProveedor.Text = Proveedor.DireccionProveedor;
                ComprasTxtEstadoProveedor.Text = Proveedor.EstadoProveedor ? "Activo" : "Inactivo";
            }
            catch (Exception Ex)
            {
                System.Diagnostics.Debug.WriteLine(Ex);
                ComprasCboNombreProveedor.ComprasMetMostrarError("No se pudieron obtener los datos del proveedor.");
            }
        }



    }
}
