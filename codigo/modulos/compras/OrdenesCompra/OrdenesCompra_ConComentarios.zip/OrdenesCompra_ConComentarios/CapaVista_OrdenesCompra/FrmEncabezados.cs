﻿using CapaVista_OrdenesCompra.Presentacion;
using System;
using System.Data;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaControlador_OrdenesCompra;
using CapaControlador_OrdenesCompra.Entidades;
using CapaVista_Componentes.Componentes;

/*
 * ==================================================================
 * Área : Compras
 * Autor : Diego Fernando Santizo Samayoa
 * Carné : 0901-22-15950
 * Fecha : 24/10/2026
 * ==================================================================
 * Propósito :
 *  Coordina la consulta y apertura de órdenes de compra desde su listado.
 * ===================================================================
*/

/*
 * EXPLICACION TEMPORAL DE LA CLASE
 * Coordina la consulta de órdenes por estado sin bloquear la interfaz y muestra un DGV de solo lectura.
 * Aplica búsqueda y fechas en memoria, controla la disponibilidad de botones y presenta errores. Libera las
 * tablas al reemplazarlas o cerrar. Para una orden nueva o una fila existente guarda la selección y cierra
 * el listado para que el contenedor cree el detalle; no cambia estados por fila.
 */

namespace CapaVista_OrdenesCompra
{
    public partial class FrmEncabezados : Form
    {
        private readonly ClsOrdenesCompra _Controlador;
        private DataTable _Datos;
        private bool _Cargando;
        private bool _AbriendoCompra;
        private bool _RestableciendoFiltros;
        public bool AbrirOrden { get; private set; }
        private ClsOrdenCompra _CompraSeleccionada;
        /// <summary>
        /// Crea el detalle con la selección guardada; exige que antes se haya solicitado abrir una orden.
        /// </summary>
        public Form ComprasFuncCrearOrdenSeleccionada()
        {
            if (!AbrirOrden) throw new InvalidOperationException("No hay una orden seleccionada.");
            return new FrmOrdenesCompra(_CompraSeleccionada, _Controlador);
        }

        /// <summary>
        /// Construye el listado con un controlador conectado al repositorio real.
        /// </summary>
        public FrmEncabezados() : this(new ClsOrdenesCompra()) { }
        /// <summary>
        /// Recibe el controlador, inicializa filtros y DGV y conecta los eventos de consulta y navegación; rechaza
        /// null.
        /// </summary>
        public FrmEncabezados(ClsOrdenesCompra Controlador)
        {
            _Controlador = Controlador ?? throw new ArgumentNullException(nameof(Controlador));
            InitializeComponent();
            ClsPresentacionCompras.ComprasMetFijarTamanoFormulario(this);
            ComprasCboEstado.Items.AddRange(new object[] { "Todos", "Pendiente", "Autorizada", "Rechazada", "Anulada", "Recibida" });
            ComprasProcRestablecerFiltros();
            ClsTablasOrdenesCompra.ComprasProcConfigurarEncabezados(ComprasDgvEncabezados);
            ComprasTxtBuscar.TextChanged += (Remitente, Evento) => ComprasProcAplicarFiltros();
            ComprasCboEstado.SelectedIndexChanged += async (Remitente, Evento) =>
            {
                if (!_RestableciendoFiltros)
                    await ComprasProcCargarDatosAsync();
            };
            ComprasUsrFechas.RangoCambiado += (Remitente, Evento) => ComprasProcAplicarFiltros();
            ComprasChkFechas.CheckedChanged += (Remitente, Evento) =>
            {
                ComprasUsrFechas.Enabled = ComprasChkFechas.Checked;
                ComprasProcAplicarFiltros();
            };
            ComprasBtnActualizar.Click += async (Remitente, Evento) => await ComprasProcRefrescarAsync();
            ComprasBtnNuevaOrden.Click += ComprasProcNuevaOrden;
            ComprasBtnCerrar.Click += (Remitente, Evento) => Close();
            ComprasDgvEncabezados.CellDoubleClick += ComprasProcAbrirCompra;
        }

        /// <summary>
        /// Ejecuta la consulta inicial de forma asíncrona después de informar la carga a la clase base.
        /// </summary>
        protected override async void OnLoad(EventArgs Evento)
        {
            base.OnLoad(Evento);
            await ComprasProcCargarDatosAsync();
        }


        /// <summary>
        /// Habilita los controles cuando no hay carga ni apertura en curso y actualiza el cursor de espera.
        /// </summary>
        private void ComprasProcActualizarDisponibilidad()
        {
            bool Disponible = !_Cargando && !_AbriendoCompra;
            ComprasBtnActualizar.Enabled = Disponible;
            ComprasBtnNuevaOrden.Enabled = Disponible;
            ComprasGbxFiltros.Enabled = Disponible;
            ComprasDgvEncabezados.Enabled = Disponible;
            ComprasBtnCerrar.Enabled = true;
            UseWaitCursor = !Disponible;
        }

        /// <summary>
        /// Consulta por estado fuera del hilo de interfaz y reemplaza las tablas anteriores, liberándolas. Descarta
        /// resultados tardíos si la ventana se cerró y muestra los errores sin conservar datos de otro filtro.
        /// </summary>
        private async Task ComprasProcCargarDatosAsync()
        {
            if (_Cargando) return;
            _Cargando = true;
            ComprasProcActualizarDisponibilidad();
            string Estado = ComprasCboEstado.Text;
            ComprasLblResultado.ColorTexto = ClsTemaCompras.PrincipalNavegador;
            ComprasLblResultado.Texto = "Cargando órdenes de compra...";
            try
            {
                DataTable Datos = await Task.Run(() => _Controlador.ComprasFuncListar(Estado));
                if (IsDisposed || Disposing)
                {
                    Datos.Dispose();
                    return;
                }
                DataTable Anteriores = _Datos;
                _Datos = Datos;
                Anteriores?.Dispose();
                ComprasProcAplicarFiltros();
            }
            catch (Exception Ex)
            {
                if (!IsDisposed && !Disposing)
                {
                    ComprasProcVaciarDatos();
                    ComprasProcMostrarError("No se pudieron cargar las órdenes de compra.", Ex);
                }
            }
            finally
            {
                _Cargando = false;
                if (!IsDisposed && !Disposing) ComprasProcActualizarDisponibilidad();
            }
        }

        /// <summary>
        /// Filtra los datos cargados por texto, estado y fechas, reemplaza la tabla del DGV y muestra el total o el
        /// error de validación.
        /// </summary>
        private void ComprasProcAplicarFiltros()
        {
            if (_Datos == null || _RestableciendoFiltros) return;
            DateTime? Inicio = ComprasChkFechas.Checked ? (DateTime?)ComprasUsrFechas.FechaInicio : null;
            DateTime? Fin = ComprasChkFechas.Checked ? (DateTime?)ComprasUsrFechas.FechaFin : null;
            DataTable Resultado;
            try
            {
                Resultado = _Controlador.ComprasFuncFiltrar(_Datos, ComprasTxtBuscar.Text, ComprasCboEstado.Text, Inicio, Fin);
            }
            catch (ArgumentException Ex)
            {
                ComprasLblResultado.ColorTexto = Color.Red;
                ComprasLblResultado.Texto = Ex.Message;
                return;
            }
            var Anterior = ComprasDgvEncabezados.DataSource as DataTable;
            ComprasDgvEncabezados.DataSource = Resultado;
            Anterior?.Dispose();
            ComprasDgvEncabezados.ClearSelection();
            if (!string.IsNullOrWhiteSpace(ComprasTxtBuscar.Text) && Resultado.Rows.Count == 0)
                ComprasTxtBuscar.ComprasMetMostrarError("No se encontraron órdenes de compra para la búsqueda.");
            else
                ComprasTxtBuscar.ComprasMetLimpiarError();
            ComprasLblResultado.ColorTexto = ClsTemaCompras.PrincipalNavegador;
            ComprasLblResultado.Texto = Resultado.Rows.Count + " órdenes de compra. Doble clic para abrir.";
        }

        /// <summary>
        /// Si la pantalla está disponible, restablece los filtros y vuelve a consultar todas las órdenes.
        /// </summary>
        private async Task ComprasProcRefrescarAsync()
        {
            if (_Cargando || _AbriendoCompra) return;
            ComprasProcRestablecerFiltros();
            await ComprasProcCargarDatosAsync();
        }

        /// <summary>
        /// Limpia texto y estado, desactiva el filtro de fechas y establece el mes actual sin disparar consultas
        /// intermedias.
        /// </summary>
        private void ComprasProcRestablecerFiltros()
        {
            _RestableciendoFiltros = true;
            try
            {
                ComprasTxtBuscar.Text = string.Empty;
                ComprasTxtBuscar.ComprasMetLimpiarError();
                ComprasCboEstado.SelectedIndex = 0;
                ComprasChkFechas.Checked = false;
                DateTime Hoy = DateTime.Today;
                ComprasUsrFechas.ComprasProcEstablecerRango(new DateTime(Hoy.Year, Hoy.Month, 1), Hoy);
                ComprasUsrFechas.Enabled = false;
            }
            finally { _RestableciendoFiltros = false; }
        }

        /// <summary>
        /// Solicita mostrar una orden nueva sin entidad seleccionada y evita aperturas simultáneas.
        /// </summary>
        private void ComprasProcNuevaOrden(object Remitente, EventArgs Evento)
        {
            if (_Cargando || _AbriendoCompra) return;
            _AbriendoCompra = true;
            try { ComprasProcMostrarOrden(null); }
            catch (Exception Ex) { ComprasProcMostrarError("No se pudo abrir la nueva orden.", Ex); }
            finally { _AbriendoCompra = false; }
        }

        /// <summary>
        /// Guarda la entidad seleccionada, activa AbrirOrden y cierra el listado para que el contenedor cree el
        /// detalle.
        /// </summary>
        private void ComprasProcMostrarOrden(ClsOrdenCompra Compra)
        {
            _CompraSeleccionada = Compra;
            AbrirOrden = true;
            Close();
        }

        /// <summary>
        /// Obtiene el PK de la fila pulsada y consulta la entidad en segundo plano; si existe, solicita abrir su
        /// detalle.
        /// </summary>
        private async void ComprasProcAbrirCompra(object Remitente, DataGridViewCellEventArgs Evento)
        {
            if (_Cargando || _AbriendoCompra || Evento.RowIndex < 0 || Evento.ColumnIndex < 0
                || Evento.RowIndex >= ComprasDgvEncabezados.Rows.Count) return;
            var Fila = ComprasDgvEncabezados.Rows[Evento.RowIndex].DataBoundItem as DataRowView;
            if (Fila == null) return;
            _AbriendoCompra = true;
            ComprasProcActualizarDisponibilidad();
            try
            {
                int Id = Convert.ToInt32(Fila["idOrdenCompra"]);
                ClsOrdenCompra Compra = await Task.Run(() => _Controlador.ComprasFuncObtener(Id));
                if (IsDisposed || Disposing) return;
                UseWaitCursor = false;
                if (Compra == null) { ComprasLblResultado.Texto = "La compra ya no esta disponible. Actualiza la lista."; return; }
                ComprasProcMostrarOrden(Compra);
            }
            catch (Exception Ex)
            {
                if (!IsDisposed && !Disposing) ComprasProcMostrarError("No se pudo abrir la compra seleccionada.", Ex);
            }
            finally
            {
                _AbriendoCompra = false;
                if (!IsDisposed && !Disposing) ComprasProcActualizarDisponibilidad();
            }
        }

        /// <summary>
        /// Desenlaza el DGV, libera la tabla filtrada y los datos originales y deja la referencia de carga en null.
        /// </summary>
        private void ComprasProcVaciarDatos()
        {
            var Resultado = ComprasDgvEncabezados.DataSource as DataTable;
            ComprasDgvEncabezados.DataSource = null;
            Resultado?.Dispose();
            _Datos?.Dispose();
            _Datos = null;
        }

        /// <summary>
        /// Libera las tablas del listado y notifica el cierre a la clase base.
        /// </summary>
        protected override void OnFormClosed(FormClosedEventArgs Evento)
        {
            ComprasProcVaciarDatos();
            base.OnFormClosed(Evento);
        }

        /// <summary>
        /// Registra la excepción en depuración y muestra el mensaje y la causa en la etiqueta de resultado.
        /// </summary>
        private void ComprasProcMostrarError(string Mensaje, Exception Ex)
        {
            System.Diagnostics.Debug.WriteLine(Ex);
            ComprasLblResultado.ColorTexto = Color.Red;
            ComprasLblResultado.Texto = Mensaje + " " + Ex.Message;
        }
    }
}
