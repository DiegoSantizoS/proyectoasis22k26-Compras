﻿using System;
using System.Data;
using CapaControlador_OrdenesCompra.Servicios;
using CapaModelo_OrdenesCompra.Contratos;
using CapaControlador_OrdenesCompra.Entidades;
using CapaModelo_OrdenesCompra.Repositorios;

/*
 * ==================================================================
 * Área : Compras
 * Autor : Diego Fernando Santizo Samayoa
 * Carné : 0901-22-15950
 * Fecha : 24/10/2026
 * ==================================================================
 * Propósito :
 *  Expone la API pública de operaciones sobre órdenes de compra.
 * ===================================================================
*/

/*
 * EXPLICACION TEMPORAL DE LA CLASE
 * Es el punto de entrada que utilizan la vista y otros módulos para trabajar con órdenes de compra. Recibe
 * un repositorio real o uno de pruebas, deriva las validaciones a los servicios y entrega las operaciones
 * de persistencia al contrato del modelo. Devuelve tablas o entidades del controlador y conserva la API
 * pública aunque cambien las clases internas. La creación registra solo el encabezado; el cambio de estado
 * no genera inventario, compras ni cuentas por pagar.
 */


namespace CapaControlador_OrdenesCompra
{
    public sealed class ClsOrdenesCompra
    {
        private readonly IRepositorioOrdenesCompra _Repositorio;

        /// <summary>
        /// Construye el controlador con el repositorio real; no abre la conexión en este constructor.
        /// </summary>
        public ClsOrdenesCompra() : this(new ClsRepositorioOrdenesCompra()) { }

        /// <summary>
        /// Recibe el repositorio que utilizará la API y rechaza null; permite inyectar un repositorio de pruebas.
        /// </summary>
        public ClsOrdenesCompra(IRepositorioOrdenesCompra Repositorio)
        {
            _Repositorio = Repositorio ?? throw new ArgumentNullException(nameof(Repositorio));
        }

        /// <summary>
        /// Devuelve todas las órdenes en una DataTable que el consumidor debe liberar.
        /// </summary>
        public DataTable ComprasFuncListar() => _Repositorio.ComprasFuncListar();
        /// <summary>
        /// Reconoce Todos o texto vacío, normaliza el estado y solicita al repositorio la consulta correspondiente.
        /// </summary>
        public DataTable ComprasFuncListar(string Estado)
        {
            if (ClsEstadosOrdenesCompra.ComprasFuncEsTodos(Estado))
                return ComprasFuncListar();
            return _Repositorio.ComprasFuncListar(ClsEstadosOrdenesCompra.ComprasFuncNormalizarEstado(Estado));
        }

        /// <summary>
        /// Valida el PK, convierte el estado a su nombre canónico y solicita su cambio al repositorio.
        /// </summary>
        public void ComprasProcCambiarEstado(int Id, string Estado)
        {
            ClsValidacionOrdenesCompra.ComprasProcValidarId(Id);
            _Repositorio.ComprasProcCambiarEstado(Id, ClsEstadosOrdenesCompra.ComprasFuncNormalizarEstado(Estado));
        }

        /// <summary>
        /// Devuelve los datos de proveedores activos como una DataTable que debe liberar el consumidor.
        /// </summary>
        public DataTable ComprasFuncListarProveedores() => _Repositorio.ComprasFuncListarProveedores();

        /// <summary>
        /// Valida el PK y devuelve la tabla de productos de esa orden; una orden sin detalles produce una tabla
        /// vacía.
        /// </summary>
        public DataTable ComprasFuncListarDetalles(int Id)
        {
            ClsValidacionOrdenesCompra.ComprasProcValidarId(Id);
            return _Repositorio.ComprasFuncListarDetalles(Id);
        }

        /// <summary>
        /// Valida el PK, solicita la anulación y vuelve a consultar la orden para verificarla y devolver su estado
        /// actualizado.
        /// </summary>
        public ClsOrdenCompra ComprasFuncAnular(int Id)
        {
            ClsValidacionOrdenesCompra.ComprasProcValidarId(Id);
            _Repositorio.ComprasProcAnular(Id);
            var Orden = ComprasFuncObtener(Id);
            if (Orden == null || Orden.Estado != "Anulada")
                throw new InvalidOperationException("No se pudo verificar la anulación. Actualiza la lista.");
            return Orden;
        }

        /// <summary>
        /// Actualiza la fecha de vencimiento de una orden pendiente sin permitir una fecha anterior a su emisión.
        /// </summary>
        public void ComprasProcActualizarVencimiento(int Id, DateTime Fecha)
        {
            var Orden = ComprasFuncObtener(Id);
            ClsValidacionOrdenesCompra.ComprasProcValidarVencimiento(Orden, Fecha);
            _Repositorio.ComprasProcActualizarVencimiento(Id, Fecha.Date);
        }

        /// <summary>
        /// Normaliza código y comentario, valida fechas e importes y delega la creación del encabezado; devuelve el
        /// PK generado.
        /// </summary>
        public int ComprasFuncCrear(string CodigoOrdenCompra, int IdProveedor, int IdPlazo, int IdMoneda, DateTime Emision,
            DateTime Vencimiento, decimal TipoCambio, decimal Subtotal, decimal Descuento, string Comentario)
        {
            CodigoOrdenCompra = ClsValidacionOrdenesCompra.ComprasFuncNormalizarCodigo(CodigoOrdenCompra);
            ClsValidacionOrdenesCompra.ComprasProcValidarCreacion(IdProveedor, IdPlazo, IdMoneda,
                Emision, Vencimiento, TipoCambio, Subtotal, Descuento);
            Comentario = ClsValidacionOrdenesCompra.ComprasFuncNormalizarComentario(Comentario);
            return _Repositorio.ComprasFuncCrear(CodigoOrdenCompra, IdProveedor, IdPlazo, IdMoneda, Emision.Date,
                Vencimiento.Date, TipoCambio, Subtotal, Descuento, Comentario);
        }

        /// <summary>
        /// Valida el PK y convierte la entidad del modelo en la entidad pública del controlador; devuelve null si no
        /// existe.
        /// </summary>
        public ClsOrdenCompra ComprasFuncObtener(int Id)
        {
            ClsValidacionOrdenesCompra.ComprasProcValidarId(Id);
            var Orden = _Repositorio.ComprasFuncObtener(Id);
            return Orden == null ? null : new ClsOrdenCompra(Orden);
        }

        /// <summary>
        /// Delega al filtro de memoria y devuelve una tabla nueva sin modificar los datos originales.
        /// </summary>
        public DataTable ComprasFuncFiltrar(DataTable Datos, string Palabra, string Estado, DateTime? Inicio, DateTime? Fin)
        {
            return ClsFiltroOrdenesCompra.ComprasFuncFiltrar(Datos, Palabra, Estado, Inicio, Fin);
        }

    }
}
