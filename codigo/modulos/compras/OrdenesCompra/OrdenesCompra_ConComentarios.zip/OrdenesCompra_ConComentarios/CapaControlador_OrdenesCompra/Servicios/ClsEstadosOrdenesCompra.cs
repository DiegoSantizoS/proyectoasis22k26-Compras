﻿using System;

/*
 * ==================================================================
 * Área : Compras
 * Autor : Diego Fernando Santizo Samayoa
 * Carné : 0901-22-15950
 * Fecha : 24/10/2026
 * ==================================================================
 * Propósito :
 *  Define los estados válidos de una orden de compra.
 * ===================================================================
*/

/*
 * EXPLICACION TEMPORAL DE LA CLASE
 * Mantiene los nombres Pendiente, Autorizada, Rechazada, Anulada y Recibida. Para la API convierte un
 * nombre con espacios o diferente capitalización a su forma canónica y reconoce cuando la consulta solicita
 * todos los estados. El filtro en memoria exige los nombres canónicos. No decide todas las transiciones de
 * negocio: las restricciones de anulación se verifican al persistir.
 */


namespace CapaControlador_OrdenesCompra.Servicios
{
    internal static class ClsEstadosOrdenesCompra
    {
        private static readonly string[] _Estados = { "Pendiente", "Autorizada", "Rechazada", "Anulada", "Recibida" };

        /// <summary>
        /// Recorta espacios y busca el nombre canónico sin distinguir mayúsculas; lanza ArgumentException para
        /// estados desconocidos.
        /// </summary>
        internal static string ComprasFuncNormalizarEstado(string Estado)
        {
            string Valor = (Estado ?? string.Empty).Trim();
            string Canonico = Array.Find(_Estados, Actual => string.Equals(Actual, Valor, StringComparison.OrdinalIgnoreCase));
            if (Canonico == null)
                throw new ArgumentException("Estado no valido. Usa Pendiente, Autorizada, Rechazada, Anulada o Recibida.", nameof(Estado));
            return Canonico;
        }

        /// <summary>
        /// Devuelve true cuando se solicita Todos sin distinguir mayúsculas, o cuando el texto es null o contiene
        /// solo espacios.
        /// </summary>
        internal static bool ComprasFuncEsTodos(string Estado)
        {
            return string.IsNullOrWhiteSpace(Estado) || string.Equals(Estado.Trim(), "Todos", StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Exige que el estado coincida exactamente con un nombre canónico; el llamador resuelve por separado el
        /// caso Todos.
        /// </summary>
        internal static void ComprasProcValidarFiltro(string Estado)
        {
            if (Array.IndexOf(_Estados, Estado) < 0)
                throw new ArgumentException("Estado no válido.", nameof(Estado));
        }
    }
}
