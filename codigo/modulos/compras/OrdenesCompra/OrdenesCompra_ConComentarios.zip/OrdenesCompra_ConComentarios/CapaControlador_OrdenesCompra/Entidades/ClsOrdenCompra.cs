﻿using System;

/*
 * ==================================================================
 * Área : Compras
 * Autor : Diego Fernando Santizo Samayoa
 * Carné : 0901-22-15950
 * Fecha : 24/10/2026
 * ==================================================================
 * Propósito :
 *  Expone los datos de una orden de compra a los consumidores del controlador.
 * ===================================================================
*/

/*
 * EXPLICACION TEMPORAL DE LA CLASE
 * Es la representacion de solo lectura que se entrega a la vista y a otros consumidores del controlador.
 * Copia los datos de la entidad del modelo para mantener separados ambos ensamblados en el uso habitual de
 * la API. Conserva el PK para las operaciones y el CodigoOrdenCompra como identificador visible;
 * NumeroOrden es un alias de ese código. No valida entradas ni ejecuta operaciones SQL.
 */


namespace CapaControlador_OrdenesCompra.Entidades
{
    public sealed class ClsOrdenCompra
    {
        public int IdOrdenCompra { get; }
        public int IdProveedor { get; }
        public string CodigoOrdenCompra { get; }
        public string NumeroOrden => CodigoOrdenCompra;
        public DateTime FechaEmision { get; }
        public DateTime FechaVencimiento { get; }
        public decimal MontoTotal { get; }
        public decimal Subtotal { get; }
        public decimal Descuento { get; }
        public int IdPlazo { get; }
        public string NombrePlazo { get; }
        public int DiasPlazo { get; }
        public int IdMoneda { get; }
        public decimal TipoCambio { get; }
        public string Comentario { get; }
        public string Estado { get; }
        public string NombreProveedor { get; }
        public string NitProveedor { get; }
        public string TelefonoProveedor { get; }
        public string CorreoProveedor { get; }
        public string DireccionProveedor { get; }
        public bool ProveedorActivo { get; }

        /// <summary>
        /// Copia los valores de la entidad del modelo a propiedades de solo lectura del controlador; rechaza una
        /// entidad null.
        /// </summary>
        internal ClsOrdenCompra(CapaModelo_OrdenesCompra.Entidades.ClsOrdenCompra Compra)
        {
            if (Compra == null) throw new ArgumentNullException(nameof(Compra));
            IdOrdenCompra = Compra.IdOrdenCompra;
            IdProveedor = Compra.IdProveedor;
            CodigoOrdenCompra = Compra.CodigoOrdenCompra;
            FechaEmision = Compra.FechaEmision;
            FechaVencimiento = Compra.FechaVencimiento;
            MontoTotal = Compra.MontoTotal;
            Subtotal = Compra.Subtotal;
            Descuento = Compra.Descuento;
            IdPlazo = Compra.IdPlazo;
            NombrePlazo = Compra.NombrePlazo;
            DiasPlazo = Compra.DiasPlazo;
            IdMoneda = Compra.IdMoneda;
            TipoCambio = Compra.TipoCambio;
            Comentario = Compra.Comentario;
            Estado = Compra.Estado;
            NombreProveedor = Compra.NombreProveedor;
            NitProveedor = Compra.NitProveedor;
            TelefonoProveedor = Compra.TelefonoProveedor;
            CorreoProveedor = Compra.CorreoProveedor;
            DireccionProveedor = Compra.DireccionProveedor;
            ProveedorActivo = Compra.ProveedorActivo;
        }
    }
}
