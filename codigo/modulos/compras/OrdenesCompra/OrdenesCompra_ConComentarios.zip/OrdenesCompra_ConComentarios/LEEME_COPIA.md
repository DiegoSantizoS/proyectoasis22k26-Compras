﻿# Copia con comentarios

Abre `OrdenesCompra.sln` de esta carpeta. Las tres capas conservan los encabezados de Diego, las explicaciones temporales de clase y los comentarios de los metodos, incluida la API.

Las capas actuales de la carpeta principal conservan solo los encabezados de autoria. El codigo ejecutable de ambas versiones es equivalente; las referencias externas de esta copia estan ajustadas a su ubicacion.
