﻿using System;
using System.Data.Odbc;

/*
 * ==================================================================
 * Área : Compras
 * Autor : Diego Fernando Santizo Samayoa
 * Carné : 0901-22-15950
 * Fecha : 24/10/2026
 * ==================================================================
 * Propósito :
 *  Traduce errores ODBC a mensajes de órdenes de compra.
 * ===================================================================
*/

/*
 * EXPLICACION TEMPORAL DE LA CLASE
 * Convierte los errores del proveedor ODBC en InvalidOperationException con mensajes comprensibles.
 * Reconoce referencias invalidas, códigos duplicados, longitudes excesivas y violaciones de integridad a
 * partir del código nativo. Si no reconoce el error, utiliza un mensaje general de acceso a datos. Conserva
 * la excepción ODBC original como InnerException para poder diagnosticar la causa.
 */

namespace CapaModelo_OrdenesCompra.Repositorios
{
    internal static class ClsErroresDatosOrdenesCompra
    {
        /// <summary>
        /// Revisa los códigos nativos ODBC y devuelve una InvalidOperationException con un mensaje funcional y el
        /// error original como InnerException; no lanza por si misma la excepción.
        /// </summary>
        internal static Exception ComprasFuncTraducirError(OdbcException Error)
        {
            string Mensaje = "No se pudo completar la operación. Verifica la conexión configurada en Seguridad.";
            foreach (OdbcError Detalle in Error.Errors)
            {
                switch (Detalle.NativeError)
                {
                    case 1451:
                    case 1452:
                        Mensaje = "La orden tiene relaciones pendientes o una referencia ya no existe.";
                        break;
                    case 1062:
                        Mensaje = "Ya existe una orden de compra con ese código.";
                        break;
                    case 1406:
                        Mensaje = "Uno de los campos excede la longitud permitida.";
                        break;
                    case 3819:
                    case 4025:
                    case 1644:
                        Mensaje = "La operación no cumple las reglas de integridad de la base de datos.";
                        break;
                }
            }
            return new InvalidOperationException(Mensaje, Error);
        }
    }
}
