﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;

/*
 * ==================================================================
 * Área : Compras
 * Autor : Diego Fernando Santizo Samayoa
 * Carné : 0901-22-15950
 * Fecha : 24/10/2026
 * ==================================================================
 * Propósito :
 *  Persiste los cambios de las órdenes de compra.
 * ===================================================================
*/

/*
 * EXPLICACION TEMPORAL DE LA CLASE
 * Contiene las escrituras SQL: creación del encabezado, actualización de vencimiento, anulación y cambio de
 * estado. La creación y el cambio general de estado utilizan transacciones; este ultimo bloquea la orden
 * antes de actualizarla. Rechaza anular órdenes recibidas o con compras registradas y comprueba los
 * registros afectados. Inserta el código unico y obtiene el PK con LAST_INSERT_ID en la misma conexión, sin
 * crear productos ni movimientos de otros módulos.
 */

namespace CapaModelo_OrdenesCompra.Repositorios
{
    internal sealed class ClsComandosOrdenesCompra : ClsRepositorioBaseOrdenesCompra
    {
        /// <summary>
        /// Bloquea la orden en una transaccion, comprueba existencia y estado actual, y actualiza solo esa fila.
        /// Repetir el mismo estado no escribe; anular una orden recibida o con compras registradas se rechaza.
        /// </summary>
        internal void ComprasProcCambiarEstado(int Id, string Estado)
        {
            ComprasProcValidarId(Id);
            ComprasFuncEjecutar((Conexion, Transaccion) =>
            {
                var Parametros = new List<OdbcParameter> { new OdbcParameter("Id", OdbcType.Int) { Value = Id } };
                using (var Consulta = ComprasFuncCrearComando(Conexion, Transaccion,
                    "SELECT estadoOrdenCompra FROM tblOrdenCompra WHERE idOrdenCompra = ? FOR UPDATE", CommandType.Text, Parametros))
                {
                    object Actual = Consulta.ExecuteScalar();
                    if (Actual == null)
                        throw new InvalidOperationException("La orden de compra no existe.");
                    if (Convert.ToString(Actual) == Estado)
                        return 0;
                    if (Estado == "Anulada" && Convert.ToString(Actual) == "Recibida")
                        throw new InvalidOperationException("No se puede anular una orden recibida.");
                }
                Parametros = new List<OdbcParameter>
                {
                    new OdbcParameter("Estado", OdbcType.VarChar, 30) { Value = Estado },
                    new OdbcParameter("Id", OdbcType.Int) { Value = Id }
                };
                string Sql = "UPDATE tblOrdenCompra SET estadoOrdenCompra = ? WHERE idOrdenCompra = ?";
                if (Estado == "Anulada")
                    Sql += " AND NOT EXISTS (SELECT 1 FROM tblCompra c WHERE c.idOrdenCompra = tblOrdenCompra.idOrdenCompra)";
                using (var Comando = ComprasFuncCrearComando(Conexion, Transaccion, Sql, CommandType.Text, Parametros))
                {
                    int Afectadas = Comando.ExecuteNonQuery();
                    if (Afectadas != 1)
                        throw new InvalidOperationException("No se pudo cambiar el estado. La orden puede tener una compra registrada.");
                    return Afectadas;
                }
            }, true);
        }

        /// <summary>
        /// Actualiza a Anulada solo una orden pendiente, autorizada o rechazada y sin compras vinculadas; exige
        /// exactamente una fila afectada.
        /// </summary>
        internal void ComprasProcAnular(int Id)
        {
            ComprasProcValidarId(Id);
            int Afectadas = ComprasFuncEjecucionNonQuery("UPDATE tblOrdenCompra o SET estadoOrdenCompra = 'Anulada' "
                + "WHERE o.idOrdenCompra = ? AND o.estadoOrdenCompra IN ('Pendiente', 'Autorizada', 'Rechazada') "
                + "AND NOT EXISTS (SELECT 1 FROM tblCompra c WHERE c.idOrdenCompra = o.idOrdenCompra)",
                new List<OdbcParameter> { new OdbcParameter("Id", OdbcType.Int) { Value = Id } }, CommandType.Text);
            if (Afectadas != 1)
                throw new InvalidOperationException("La orden no existe, ya está anulada o tiene una compra registrada.");
        }

        /// <summary>
        /// Ejecuta una actualización condicionada a estado Pendiente y fechas coherentes. Si no se reportan cambios,
        /// consulta el valor actual para distinguir una fecha ya guardada de una operación fallida.
        /// </summary>
        internal void ComprasProcActualizarVencimiento(int Id, DateTime Fecha)
        {
            ComprasProcValidarId(Id);
            int Afectadas = ComprasFuncEjecucionNonQuery("UPDATE tblOrdenCompra SET fechaVencimientoOrdenCompra = ? "
                + "WHERE idOrdenCompra = ? AND fechaEmisionOrdenCompra <= ? AND estadoOrdenCompra = 'Pendiente'",
                new List<OdbcParameter>
                {
                    new OdbcParameter("Fecha", OdbcType.Date) { Value = Fecha.Date },
                    new OdbcParameter("Id", OdbcType.Int) { Value = Id },
                    new OdbcParameter("Emision", OdbcType.Date) { Value = Fecha.Date }
                }, CommandType.Text);
            if (Afectadas == 0)
            {
                var Orden = new ClsConsultasOrdenesCompra().ComprasFuncObtener(Id);
                if (Orden == null || Orden.Estado != "Pendiente" || Orden.FechaVencimiento != Fecha.Date)
                    throw new InvalidOperationException("No se pudo actualizar el vencimiento de la orden pendiente.");
            }
        }

        /// <summary>
        /// Inserta el encabezado si existen el proveedor activo y el plazo, parametriza el código y calcula el
        /// total. Obtiene LAST_INSERT_ID en la misma conexión y confirma la transaccion; la base impide códigos
        /// duplicados.
        /// </summary>
        internal int ComprasFuncCrear(string CodigoOrdenCompra, int IdProveedor, int IdPlazo, int IdMoneda, DateTime Emision,
            DateTime Vencimiento, decimal TipoCambio, decimal Subtotal, decimal Descuento, string Comentario)
        {
            const string Sql = "INSERT INTO tblOrdenCompra (codigoOrdenCompra, idProveedor, idPlazo, idMoneda, "
                + "fechaEmisionOrdenCompra, fechaVencimientoOrdenCompra, tipoCambioOrdenCompra, "
                + "subtotalOrdenCompra, descuentoOrdenCompra, totalOrdenCompra, comentarioOrdenCompra) "
                + "SELECT ?, p.idProveedor, z.idPlazo, ?, ?, ?, ?, ?, ?, ?, ? FROM tblProveedor p "
                + "CROSS JOIN tblPlazo z WHERE p.idProveedor = ? AND p.estadoProveedor = 1 AND z.idPlazo = ?";
            return ComprasFuncEjecutar((Conexion, Transaccion) =>
            {
                var Parametros = new List<OdbcParameter>
                {
                    new OdbcParameter("CodigoOrdenCompra", OdbcType.VarChar, 30) { Value = CodigoOrdenCompra },
                    new OdbcParameter("Moneda", OdbcType.Int) { Value = IdMoneda },
                    new OdbcParameter("Emision", OdbcType.Date) { Value = Emision.Date },
                    new OdbcParameter("Vencimiento", OdbcType.Date) { Value = Vencimiento.Date },
                    ComprasFuncParametroDecimal("TipoCambio", TipoCambio, 6),
                    ComprasFuncParametroDecimal("Subtotal", Subtotal, 4),
                    ComprasFuncParametroDecimal("Descuento", Descuento, 4),
                    ComprasFuncParametroDecimal("Total", Subtotal - Descuento, 4),
                    new OdbcParameter("Comentario", OdbcType.VarChar, 500) { Value = (object)Comentario ?? DBNull.Value },
                    new OdbcParameter("Proveedor", OdbcType.Int) { Value = IdProveedor },
                    new OdbcParameter("Plazo", OdbcType.Int) { Value = IdPlazo }
                };
                using (var Comando = ComprasFuncCrearComando(Conexion, Transaccion, Sql, CommandType.Text, Parametros))
                {
                    if (Comando.ExecuteNonQuery() != 1)
                        throw new InvalidOperationException("El proveedor está inactivo o el plazo no existe.");
                    Comando.Parameters.Clear();
                    Comando.CommandText = "SELECT LAST_INSERT_ID()";
                    return Convert.ToInt32(Comando.ExecuteScalar());
                }
            }, true);
        }

        /// <summary>
        /// Construye un parámetro ODBC decimal con precision 12, la escala indicada y el valor recibido para
        /// conservar la precision monetaria.
        /// </summary>
        private static OdbcParameter ComprasFuncParametroDecimal(string Nombre, decimal Valor, byte Escala)
        {
            return new OdbcParameter(Nombre, OdbcType.Decimal) { Precision = 12, Scale = Escala, Value = Valor };
        }

        /// <summary>
        /// Comprueba que Id sea positivo; lanza ArgumentOutOfRangeException si no puede representar un PK válido.
        /// </summary>
        private static void ComprasProcValidarId(int Id)
        {
            if (Id <= 0)
                throw new ArgumentOutOfRangeException(nameof(Id));
        }
    }
}
