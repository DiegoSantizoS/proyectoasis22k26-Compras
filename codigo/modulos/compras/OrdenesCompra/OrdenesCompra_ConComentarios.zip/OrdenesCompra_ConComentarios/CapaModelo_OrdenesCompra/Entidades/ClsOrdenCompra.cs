﻿using System;
using System.Data;

/*
 * ==================================================================
 * Área : Compras
 * Autor : Diego Fernando Santizo Samayoa
 * Carné : 0901-22-15950
 * Fecha : 24/10/2026
 * ==================================================================
 * Propósito :
 *  Representa los datos persistidos de una orden de compra.
 * ===================================================================
*/

/*
 * EXPLICACION TEMPORAL DE LA CLASE
 * Convierte una fila consultada en una entidad de solo lectura con código, PK, fechas, importes, estado,
 * plazo, moneda y datos del proveedor. Espera que existan las columnas del SELECT del modelo y utiliza
 * conversiones de tipos para recuperar sus valores. Un proveedor cuyo estado sea NULL se interpreta como
 * inactivo. No representa los productos: estos se consultan por separado como una tabla de detalles.
 */


namespace CapaModelo_OrdenesCompra.Entidades
{
    public sealed class ClsOrdenCompra
    {
        public int IdOrdenCompra { get; }
        public int IdProveedor { get; }
        public string CodigoOrdenCompra { get; }
        public string NumeroOrden => CodigoOrdenCompra;
        public DateTime FechaEmision { get; }
        public DateTime FechaVencimiento { get; }
        public decimal MontoTotal { get; }
        public decimal Subtotal { get; }
        public decimal Descuento { get; }
        public int IdPlazo { get; }
        public string NombrePlazo { get; }
        public int DiasPlazo { get; }
        public int IdMoneda { get; }
        public decimal TipoCambio { get; }
        public string Comentario { get; }
        public string Estado { get; }
        public string NombreProveedor { get; }
        public string NitProveedor { get; }
        public string TelefonoProveedor { get; }
        public string CorreoProveedor { get; }
        public string DireccionProveedor { get; }
        public bool ProveedorActivo { get; }

        /// <summary>
        /// Lee las columnas esperadas de Fila y convierte sus valores a propiedades de la entidad; rechaza una fila
        /// null.
        /// </summary>
        public ClsOrdenCompra(DataRow Fila)
        {
            if (Fila == null) throw new ArgumentNullException(nameof(Fila));
            IdOrdenCompra = Convert.ToInt32(Fila["idOrdenCompra"]);
            IdProveedor = Convert.ToInt32(Fila["idProveedor"]);
            CodigoOrdenCompra = Convert.ToString(Fila["codigoOrdenCompra"]);
            FechaEmision = Convert.ToDateTime(Fila["fechaEmisionOrdenCompra"]).Date;
            FechaVencimiento = Convert.ToDateTime(Fila["fechaVencimientoOrdenCompra"]).Date;
            MontoTotal = Convert.ToDecimal(Fila["totalOrdenCompra"]);
            Subtotal = Convert.ToDecimal(Fila["subtotalOrdenCompra"]);
            Descuento = Convert.ToDecimal(Fila["descuentoOrdenCompra"]);
            IdPlazo = Convert.ToInt32(Fila["idPlazo"]);
            NombrePlazo = Convert.ToString(Fila["nombrePlazo"]);
            DiasPlazo = Convert.ToInt32(Fila["diasPlazo"]);
            IdMoneda = Convert.ToInt32(Fila["idMoneda"]);
            TipoCambio = Convert.ToDecimal(Fila["tipoCambioOrdenCompra"]);
            Comentario = Convert.ToString(Fila["comentarioOrdenCompra"]);
            Estado = Convert.ToString(Fila["estadoOrdenCompra"]);
            NombreProveedor = Convert.ToString(Fila["nombreProveedor"]);
            NitProveedor = Convert.ToString(Fila["nitProveedor"]);
            TelefonoProveedor = Convert.ToString(Fila["telefonoProveedor"]);
            CorreoProveedor = Convert.ToString(Fila["correoProveedor"]);
            DireccionProveedor = Convert.ToString(Fila["direccionProveedor"]);
            ProveedorActivo = !Fila.IsNull("estadoProveedor") && Convert.ToBoolean(Fila["estadoProveedor"]);
        }
    }
}
