﻿using System.Data;
using CapaModelo_OrdenesCompra.Entidades;

/*
 * ==================================================================
 * Área : Compras
 * Autor : Diego Fernando Santizo Samayoa
 * Carné : 0901-22-15950
 * Fecha : 24/10/2026
 * ==================================================================
 * Propósito :
 *  Define el contrato de persistencia de órdenes de compra.
 * ===================================================================
*/

/*
 * EXPLICACION TEMPORAL DE LA CLASE
 * Esta interfaz define las operaciones que el controlador necesita para consultar y modificar órdenes de
 * compra. No contiene SQL ni una implementacion: el repositorio real y el repositorio de prueba deben
 * ofrecer las mismas firmas. Permite sustituir la persistencia sin modificar la API del controlador. Sus
 * tablas devueltas pertenecen al consumidor y deben liberarse cuando dejen de utilizarse.
 */


namespace CapaModelo_OrdenesCompra.Contratos
{
    public interface IRepositorioOrdenesCompra
    {
        /// <summary>
        /// Contrato: Devuelve todas las órdenes en una DataTable que el consumidor debe liberar. La implementacion
        /// concreta determina el acceso a datos.
        /// </summary>
        DataTable ComprasFuncListar();
        /// <summary>
        /// Contrato: Devuelve solo las órdenes del estado indicado; la API admite Todos o un valor vacío para
        /// consultar todas. La implementacion concreta determina el acceso a datos.
        /// </summary>
        DataTable ComprasFuncListar(string Estado);
        /// <summary>
        /// Contrato: Cambia el estado de la orden identificada por su PK y conserva las restricciones de anulación.
        /// La implementacion concreta determina el acceso a datos.
        /// </summary>
        void ComprasProcCambiarEstado(int Id, string Estado);
        /// <summary>
        /// Contrato: Valida el PK y devuelve la tabla de productos de esa orden; una orden sin detalles produce una
        /// tabla vacía. La implementacion concreta determina el acceso a datos.
        /// </summary>
        DataTable ComprasFuncListarDetalles(int Id);
        /// <summary>
        /// Contrato: Busca una orden por PK y devuelve sus datos, o null cuando no existe. La implementacion
        /// concreta determina el acceso a datos.
        /// </summary>
        ClsOrdenCompra ComprasFuncObtener(int Id);
        /// <summary>
        /// Contrato: Devuelve los datos de proveedores activos como una DataTable que debe liberar el consumidor. La
        /// implementacion concreta determina el acceso a datos.
        /// </summary>
        DataTable ComprasFuncListarProveedores();
        /// <summary>
        /// Contrato: Solicita anular la orden indicada, respetando las restricciones de estado y de compras
        /// registradas. La implementacion concreta determina el acceso a datos.
        /// </summary>
        void ComprasProcAnular(int Id);
        /// <summary>
        /// Contrato: Actualiza la fecha de vencimiento de una orden pendiente sin permitir una fecha anterior a su
        /// emisión. La implementacion concreta determina el acceso a datos.
        /// </summary>
        void ComprasProcActualizarVencimiento(int Id, System.DateTime Fecha);
        /// <summary>
        /// Contrato: Registra un encabezado con su código obligatorio y devuelve el PK generado; no inserta
        /// productos. La implementacion concreta determina el acceso a datos.
        /// </summary>
        int ComprasFuncCrear(string CodigoOrdenCompra, int IdProveedor, int IdPlazo, int IdMoneda, System.DateTime Emision,
            System.DateTime Vencimiento, decimal TipoCambio, decimal Subtotal, decimal Descuento, string Comentario);
    }
}
