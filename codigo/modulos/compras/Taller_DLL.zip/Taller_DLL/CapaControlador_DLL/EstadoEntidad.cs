﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaControlador_DLL
{
    public enum EstadoEntidad
    {
        Added,
        Deleted,
        Modified
    }
}
