using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data.Odbc;
using System.Linq;
using CapaModelo_DLL.Contratos;
using CapaModelo_DLL.Entidades;
using CapaModelo_DLL.Repositorios;

namespace CapaControlador_DLL
{
    public class ModeloCiudad
    {
        private readonly IRepositorioCiudad repositorio = new RepositorioCiudad();
        private List<ModeloCiudad> roles = new List<ModeloCiudad>();
        [Browsable(false)]
        public EstadoEntidad Estado { private get; set; }
        public int idRol { get; set; }
        [Required(ErrorMessage = "Nombre es obligatorio.")]
        [StringLength(100, ErrorMessage = "Nombre permite hasta 100 caracteres.")]
        public string nombreRol { get; set; }
        [Required(ErrorMessage = "Descripción es obligatoria.")]
        [StringLength(255, ErrorMessage = "Descripción permite hasta 255 caracteres.")]
        public string descripcionRol { get; set; }
        public bool is_active { get; set; } = true;
        public DateTime created_at { get; set; }
        public DateTime updated_at { get; set; }

        public string GrabarCambios()
        {
            var entidad = new Ciudad
            {
                idRol = this.idRol,
                nombreRol = this.nombreRol,
                descripcionRol = this.descripcionRol,
                is_active = this.is_active,
                created_at = this.created_at,
                updated_at = this.updated_at,
            };
            try
            {
                switch (Estado)
                {
                    case EstadoEntidad.Added:
                        repositorio.Agregar(entidad);
                        return "Rol agregado correctamente";
                    case EstadoEntidad.Modified:
                        repositorio.Editar(entidad);
                        return "Rol modificado correctamente";
                    case EstadoEntidad.Deleted:
                        repositorio.Remover(entidad);
                        return "Rol eliminado correctamente";
                    default:
                        throw new InvalidOperationException("Seleccione una operación.");
                }
            }
            catch (OdbcException ex)
            {
                if (ex.Errors.Cast<OdbcError>().Any(error => error.NativeError == 1062))
                    throw new InvalidOperationException("El nombre ya pertenece a otro rol.", ex);
                throw;
            }
        }

        public List<ModeloCiudad> GetAll()
        {
            roles = repositorio.GetAll().Select(item => new ModeloCiudad
            {
                idRol = item.idRol,
                nombreRol = item.nombreRol,
                descripcionRol = item.descripcionRol,
                is_active = item.is_active,
                created_at = item.created_at,
                updated_at = item.updated_at,
            }).ToList();
            return roles;
        }

        public IEnumerable<ModeloCiudad> FindbyID(string filter)
        {
            filter = (filter ?? "").Trim();
            return roles.Where(e => new[] { e.idRol.ToString(), e.nombreRol, e.descripcionRol }
                .Any(value => (value ?? "").IndexOf(filter, StringComparison.CurrentCultureIgnoreCase) >= 0)).ToList();
        }
    }
}
