﻿using CapaModelo_DLL.Repositorios;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaControlador_DLL
{
    public class ModeloCombo
    {
        RepositorioCombo sentencias = new RepositorioCombo();

        public DataTable EnviarDatos(string tabla, string campo1, string campo2)
        {
            var dtTabla = sentencias.ObtenerDatos(tabla, campo1, campo2);

            return dtTabla;
        }
    }
}