using System;

namespace CapaModelo_DLL.Entidades
{
    public class Ciudad
    {
        public int idRol { get; set; }
        public string nombreRol { get; set; }
        public string descripcionRol { get; set; }
        public bool is_active { get; set; }
        public DateTime created_at { get; set; }
        public DateTime updated_at { get; set; }
    }
}
