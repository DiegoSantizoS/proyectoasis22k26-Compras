﻿using System;
using System.Collections.Generic;
using System.Data.Odbc;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaModelo_DLL.Repositorios
{
    public abstract class Repositorio
    {
        public readonly string connectionString;
        public Repositorio()
        {
            connectionString = "Dsn=EmbutidosS.A";
        }

        public OdbcConnection obtenerConexion()
        {
            return new OdbcConnection(connectionString);
        }
    }
}
