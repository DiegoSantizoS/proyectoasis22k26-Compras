using CapaModelo_DLL.Contratos;
using CapaModelo_DLL.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;

namespace CapaModelo_DLL.Repositorios
{
    public class RepositorioCiudad : RepositorioMaestro, IRepositorioCiudad
    {
        private readonly string selectAll = "SELECT idRol, nombreRol, descripcionRol, is_active, created_at, updated_at FROM tblrol ORDER BY idRol ASC";
        private readonly string insert = "INSERT INTO tblrol (nombreRol, descripcionRol, is_active) VALUES (?, ?, ?)";
        private readonly string update = "UPDATE tblrol SET nombreRol=?, descripcionRol=?, is_active=? WHERE idRol=?";
        private readonly string delete = "DELETE FROM tblrol WHERE idRol=?";
        private List<OdbcParameter> Parametros(Ciudad entidad)
        {
            return new List<OdbcParameter>
            {
                new OdbcParameter("nombreRol", OdbcType.VarChar, 100) { Value = entidad.nombreRol },
                new OdbcParameter("descripcionRol", OdbcType.VarChar, 255) { Value = entidad.descripcionRol },
                new OdbcParameter("is_active", OdbcType.TinyInt) { Value = entidad.is_active ? 1 : 0 },
            };
        }

        public int Agregar(Ciudad entidad)
        {
            return EjecucionNonQuery(insert, Parametros(entidad), CommandType.Text);
        }

        public int Editar(Ciudad entidad)
        {
            var parametros = Parametros(entidad);
            parametros.Add(new OdbcParameter("idRol", OdbcType.Int) { Value = entidad.idRol });
            return EjecucionNonQuery(update, parametros, CommandType.Text);
        }

        public int Remover(Ciudad entidad)
        {
            return EjecucionNonQuery(delete, new List<OdbcParameter>
            {
                new OdbcParameter("idRol", OdbcType.Int) { Value = entidad.idRol }
            }, CommandType.Text);
        }

        public IEnumerable<Ciudad> GetAll()
        {
            var roles = new List<Ciudad>();
            using (var tabla = EjecucionConsulta(selectAll, CommandType.Text))
            {
                foreach (DataRow row in tabla.Rows)
                {
                    roles.Add(new Ciudad
                    {
                        idRol = Convert.ToInt32(row["idRol"]),
                        nombreRol = row["nombreRol"].ToString(),
                        descripcionRol = row["descripcionRol"].ToString(),
                        is_active = Convert.ToBoolean(row["is_active"]),
                        created_at = Convert.ToDateTime(row["created_at"]),
                        updated_at = Convert.ToDateTime(row["updated_at"]),
                    });
                }
            }
            return roles;
        }
    }
}
