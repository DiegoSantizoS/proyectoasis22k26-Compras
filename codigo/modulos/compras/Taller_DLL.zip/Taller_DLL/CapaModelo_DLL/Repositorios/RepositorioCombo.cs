﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaModelo_DLL.Repositorios
{
    public class RepositorioCombo : Repositorio
    {
        public DataTable ObtenerDatos(string tabla, string campo1, string campo2)
        {
            string sql = "SELECT " + campo1 + ", " + campo2 +
                         " FROM " + tabla;

            OdbcCommand command = new OdbcCommand(sql, obtenerConexion());
            OdbcDataAdapter adaptador = new OdbcDataAdapter(command);

            DataTable dtDatos = new DataTable();
            adaptador.Fill(dtDatos);

            return dtDatos;
        }
    }
}