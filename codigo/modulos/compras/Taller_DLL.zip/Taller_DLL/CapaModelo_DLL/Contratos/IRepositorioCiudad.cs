﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaModelo_DLL.Entidades;

namespace CapaModelo_DLL.Contratos
{
    public interface IRepositorioCiudad : IRepositorioGenerico<Ciudad>
    {
    }
}
