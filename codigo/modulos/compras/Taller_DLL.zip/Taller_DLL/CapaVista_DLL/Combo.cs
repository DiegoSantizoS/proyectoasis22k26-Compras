﻿using CapaControlador_DLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaVista_DLL
{
    public partial class Combo : UserControl
    {
        public Combo()
        {
            InitializeComponent();
        }
        ModeloCombo controlador = new ModeloCombo();
        public void LlenarCombo(string tabla, string campo1, string campo2)
        {
            var dtTabla = controlador.EnviarDatos(tabla, campo1, campo2);

            cboPrueba.DataSource = dtTabla;
            cboPrueba.ValueMember = campo1;
            cboPrueba.DisplayMember = campo2;

            AutoCompleteStringCollection coleccion = new AutoCompleteStringCollection();

            foreach (DataRow row in dtTabla.Rows)
            {
                coleccion.Add(Convert.ToString(row[campo1]) + "-" +
                              Convert.ToString(row[campo2]));

                coleccion.Add(Convert.ToString(row[campo2]) + "-" +
                              Convert.ToString(row[campo1]));
            }

            cboPrueba.AutoCompleteCustomSource = coleccion;
            cboPrueba.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            cboPrueba.AutoCompleteSource = AutoCompleteSource.CustomSource;
        }
    }
}