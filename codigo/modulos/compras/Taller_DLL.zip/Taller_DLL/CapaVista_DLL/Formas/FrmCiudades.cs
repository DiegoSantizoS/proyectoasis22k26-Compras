using CapaControlador_DLL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace CapaVista_DLL.Formas
{
    public partial class FrmCiudades : Form
    {
        private ModeloCiudad ciudad = new ModeloCiudad();
        private readonly Dictionary<string, Control> campos = new Dictionary<string, Control>();

        public FrmCiudades()
        {
            InitializeComponent();
            Text = "Roles";
            ConfigurarCampos();
            dgvCiudades.ReadOnly = true;
            dgvCiudades.AllowUserToAddRows = false;
            dgvCiudades.MultiSelect = false;
            dgvCiudades.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Reinicio();
        }

        private void ConfigurarCampos()
        {
            pnlIngresoDeDatos.AutoScroll = true;
            label2.Text = "Nombre";
            label2.Location = new Point(0, 0);
            txtNombre.Location = new Point(0, 20);
            txtNombre.Width = 145;
            txtNombre.MaxLength = 100;
            txtNombre.TabIndex = 0;
            campos.Add("nombreRol", txtNombre);
            int top = 50;
            AgregarCampo("descripcionRol", "Descripción", new TextBox { MaxLength = 255 }, ref top);
            AgregarCampo("is_active", "Activo", new CheckBox { Checked = true }, ref top);
            btnGrabar.Location = new Point(28, top);
            btnGrabar.TabIndex = campos.Count;
            pnlIngresoDeDatos.AutoScrollMinSize = new Size(0, top + 45);
        }

        private void AgregarCampo(string nombre, string titulo, Control control, ref int top)
        {
            pnlIngresoDeDatos.Controls.Add(new Label
            {
                Text = titulo, AutoSize = true, Location = new Point(0, top)
            });
            control.Name = nombre;
            control.Location = new Point(0, top + 20);
            control.Size = new Size(145, 24);
            control.TabIndex = campos.Count;
            pnlIngresoDeDatos.Controls.Add(control);
            campos.Add(nombre, control);
            top += 50;
        }

        private void FrmCiudades_Load_1(object sender, EventArgs e)
        {
            listaCiudades();
        }

        private void listaCiudades()
        {
            try
            {
                ciudad.GetAll();
                dgvCiudades.DataSource = ciudad.FindbyID(txtFiltro.Text);
                combo1.LlenarCombo("tblrol", "idRol", "nombreRol");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar roles: " + ex.Message);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            dgvCiudades.DataSource = ciudad.FindbyID(txtFiltro.Text);
        }

        private void txtFiltro_TextChanged(object sender, EventArgs e)
        {
            dgvCiudades.DataSource = ciudad.FindbyID(txtFiltro.Text);
        }

        private void btnGrabar_Click(object sender, EventArgs e)
        {
            ciudad.nombreRol = campos["nombreRol"].Text.Trim();
            ciudad.descripcionRol = campos["descripcionRol"].Text.Trim();
            ciudad.is_active = ((CheckBox)campos["is_active"]).Checked;
            if (!new Ayudas.ValidacionDatos(ciudad).Validar())
                return;
            try
            {
                MessageBox.Show(ciudad.GrabarCambios());
                Reinicio();
                listaCiudades();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al grabar rol: " + ex.Message);
            }
        }

        private void Reinicio()
        {
            pnlIngresoDeDatos.Enabled = false;
            foreach (Control campo in campos.Values)
            {
                if (campo is TextBox) ((TextBox)campo).Clear();
                else if (campo is DateTimePicker) ((DateTimePicker)campo).Value = DateTime.Today;
                else if (campo is ComboBox) ((ComboBox)campo).SelectedIndex = -1;
                else if (campo is CheckBox) ((CheckBox)campo).Checked = true;
            }
            pnlIngresoDeDatos.AutoScrollPosition = Point.Empty;
            txtFiltro.Clear();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            Reinicio();
            ciudad.idRol = 0;
            ciudad.Estado = EstadoEntidad.Added;
            pnlIngresoDeDatos.Enabled = true;
            txtNombre.Focus();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            var seleccionado = dgvCiudades.CurrentRow == null ? null
                : dgvCiudades.CurrentRow.DataBoundItem as ModeloCiudad;
            if (seleccionado == null)
            {
                MessageBox.Show("Seleccione una fila");
                return;
            }
            ciudad.idRol = seleccionado.idRol;
            ciudad.Estado = EstadoEntidad.Modified;
            campos["nombreRol"].Text = seleccionado.nombreRol;
            campos["descripcionRol"].Text = seleccionado.descripcionRol;
            ((CheckBox)campos["is_active"]).Checked = seleccionado.is_active;
            pnlIngresoDeDatos.Enabled = true;
            pnlIngresoDeDatos.AutoScrollPosition = Point.Empty;
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            var seleccionado = dgvCiudades.CurrentRow == null ? null
                : dgvCiudades.CurrentRow.DataBoundItem as ModeloCiudad;
            if (seleccionado == null)
            {
                MessageBox.Show("Seleccione una fila");
                return;
            }
            try
            {
                ciudad.Estado = EstadoEntidad.Deleted;
                ciudad.idRol = seleccionado.idRol;
                MessageBox.Show(ciudad.GrabarCambios());
                Reinicio();
                listaCiudades();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al borrar rol: " + ex.Message);
            }
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            FrmReporte reporte = new FrmReporte();
            reporte.Show();
        }
    }
}
