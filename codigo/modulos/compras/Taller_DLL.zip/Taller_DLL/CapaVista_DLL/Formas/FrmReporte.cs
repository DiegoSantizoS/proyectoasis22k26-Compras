﻿using CapaControlador_DLL;
using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaVista_DLL.Formas
{
    public partial class FrmReporte : Form
    {

        ModeloCiudad ciudad = new ModeloCiudad();
        public FrmReporte()
        {
            InitializeComponent();
        }

        private void FrmReporte_Load(object sender, EventArgs e)
        {
            ReportDataSource reportDataSource = new ReportDataSource("DataSet1", ciudad.GetAll());
            reportViewer1.LocalReport.ReportEmbeddedResource = "CapaVista_DLL.Reportes.Report1.rdlc";
            reportViewer1.LocalReport.DataSources.Clear(); 
            reportViewer1.LocalReport.DataSources.Add(reportDataSource);
            this.reportViewer1.RefreshReport();

        }
    }
}
