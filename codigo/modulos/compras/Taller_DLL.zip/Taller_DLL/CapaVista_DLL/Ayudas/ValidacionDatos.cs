﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CapaVista_DLL.Ayudas
{
    public class ValidacionDatos
    {
        private ValidationContext contexto;
        private List<ValidationResult> resultado;
        private bool valido;
        private String Mensaje;

        public ValidacionDatos(object instancia)
        {
            contexto = new ValidationContext(instancia);
            resultado = new List<ValidationResult>();
            valido = Validator.TryValidateObject(instancia, contexto, resultado, true);
        }

        public bool Validar()
        {
            if (!valido)
            {
                foreach (ValidationResult item in resultado)
                {
                    Mensaje += item.ErrorMessage + Environment.NewLine;
                }
                System.Windows.Forms.MessageBox.Show(Mensaje);
            }
            return valido;
        }
    }
}
